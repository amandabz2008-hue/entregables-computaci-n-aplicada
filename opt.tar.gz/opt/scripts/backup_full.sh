#!/bin/bash

# Variables
ORIGEN=$1
DESTINO=$2
FECHA=`date +%Y%m%d`

# 5.5 Opcion de ayuda para guiar al usuario
if [[ "$1" == "-help" ]]; then
    echo "Uso: backup_full.sh ORIGEN DESTINO"
    echo "Ejemplo: backup_full.sh /var/log /backup_dir"
    exit 0
fi

# 5.4 Validar argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: debe indicar origen y destino"
    echo "Utilice -help para ver las instrucciones"
    exit 1
fi

# 5 Validar directorio origen
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el directorio de origen no existe"
    exit 1
fi

# 5.6 Validar archivos de origen
if ! findmnt -T "$ORIGEN" > /dev/null 2>&1; then
    echo "Error: el sistema de archivos de origen no esta disponible"
    exit 1
fi

# 5.6 Validar archivos de destino
if [[ ! -d "$DESTINO" ]] || ! mountpoint -q "$DESTINO"; then
    echo "Error: el destino no esta montado o disponible"
    exit 1
fi

# 5.2 y 5.3 Nombre backup
NOMBRE=`basename "$ORIGEN"`
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Hacer backup
echo "Iniciando backup de $ORIGEN..."

if tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE"; then
    echo "Backup realizado correctamente: $ARCHIVO"
else
    echo "Error al realizar el backup"
    exit 1
fi
