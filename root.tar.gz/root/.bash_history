history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
clear
hostnamectl set-hostname TPServer
nano /etc/hostname
hostname
clear
hostname
exit
clear
nano /etc/hostname
clear
hostname
clear
cat etc/apt/sources.list
cat /etc/debian_version
dpkg --audit
dpkg --configure --pending
dpkg --audit
apt-get -f install
apt full-upgrade
cat /etc/debian_version
cat /etc/0s-release
cat /etc/os-release
clear
shutdown now
mkdir -p /root/.ssh
chmod 700 /root/.ssh
ls /ld /root/.ssh
ls -ld /root/.ssh
cat > /tmp/clave_profesor.pub
clear
ssh-keygen -lf /tmp/clave_profesor.pub
touch /root/.ssh/authorized_keys
cat /tmp/clave_profesor.pub >> /root/.ssh/authorized_keys
chown root:root /root/.ssh/authorized_keys
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
ssh-keygen -lf /root/.ssh/authorized_keys
clear
vi /etc/ssh/sshd_config
clear
systemctl restart ssh
sshd -T | grep permitrootlogin
clear
shutdown now
dir $HOME\.ssh
echo $HOME
dir $HOME
dir "$HOME\Downloads"
pwd
dir .\clave_privada.txt
cd Desktop
dir clave_privada.txt
clear
exit
exit
clear
ls -l /root/clave_privada.txt
chmod 600 /root/clave_privada.txt
ls -l /root/clave_privada.txt
clear
ssh -i /root/clave_privada.txt root@192.168.1.241
exit
clear
exit
clear
cat /etc/network/interfaces
clear
nano /etc/network/interfaces
clear
vi /etc/network/interfaces
cat /etc/network/interfaces
clear
ip a show
ip route
clear
vi /etc/network/interfaces
cat /etc/network/interfaces
ip a
clear
cat /etc/network/interfaces
shutdown now
ls -l /root/clave_privada.txt
cat /root/clave_privada.txt
clear
exit
clear
exit
cat authorized_keys
clear
exit
clear
clear
exit
exit
exit
clear
apache2 -v
php -v
ls -l /root/index.php
clear
lsblk
clear
/etc/apache2/apache2.conf
vi /etc/apache2/apache2.conf
ls -l /var/www/html
cat /etc/apache2/sites-available/000-default.conf
ls -l /root/index.php /root/logo.png
clear
dir "C:\Users\amand\OneDrive\Documentos\TP_computacion"
shutdown now
clear
ls -l /root/index.php /root/logo.png
clear
mkdir -p /var/www/tp-web
cp /root/index.php /root/logo.png /var/www/tp-web/
chmod 644 /var/www/tp-web/index.php /var/www/tp-web/logo.png
ls -l /var/www/tp-web
clear
vi /etc/apache2/sites-available/000-default.conf
clear
vi /etc/apache2/sites-available/000-default.conf
apache2ctl configtest
clear
systemctl reload apache2
systemctl status apache2
clear
shutdown now
clear
lsblk
clear
fdisk /dev/sdc
clear
lsblk
clear
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
lsblk -f
clear
mkdir /www_dir
mkdir /backup_dir
clear
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
lsblk
clear
ls -la /var/www/tp-web
cp /var/www/tp-web/index.php /www_dir/
cp /var/www/tp-web/logo.png /www_dir/
ls -la /www_dir
clear
nano /etc/apache2/sites-available/000-default.conf
clear
vi /etc/apache2/sites-available/000-default.conf
clear
apache2ctl configtest
clear
systemctl reload apache2
curl -I http://localhost
clear
vi /etc/apache2/apache2.conf
clear
setxkbmap us
dpkg-reconfigure keyboard-configuration
clear
loadkeys us
echo $TERM
cat /etc/default/keyboard
setupcon
clear
vi /etc/apache2/apache2.conf
clear
apachectl configtest
apache2ctl configtest
vi /etc/apache2/apache2.conf
apache2ctl configtest
clear
blkid
cp /etc/fstab /etc/fstab.bak
clear
vi /etc/fstab
clear
mount -a
df -h
reboot
df -h
shutdown now
clear
shutdown now
clear
ls -l /opt/scripts
clear
mkdir -p /opt/scripts
cd /opt/scripts
pwd
clear
cd /root
clear
ls -ld /www_dir /backup_dir
df -h
ls -ld /var/log /var/logs
ls -ld /var/log
clear
vi backup_full.sh
rm backup_full.sh
vi /opt/scripts/backup_full.sh
clear
clear
systemctl status cron
clear
crontab -e
crontab -l
chmod 755 /opt/scripts/backup_full.sh
clear
shutdown now
